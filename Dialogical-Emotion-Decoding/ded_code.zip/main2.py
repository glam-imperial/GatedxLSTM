## importing dependencies
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from torch.utils.data import DataLoader, TensorDataset
from collections import defaultdict
import pandas as pd
import math
from sklearn.metrics import accuracy_score, f1_score
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from ded import beam_search as bs
from ded.arguments import parse_args
from ded import utils
import re
import os
import sys
import numpy as np
import joblib
import logging
import json

import warnings
from xlstm import (
    xLSTMBlockStack,
    xLSTMBlockStackConfig,
    mLSTMBlockConfig,
    mLSTMLayerConfig,
    sLSTMBlockConfig,
    sLSTMLayerConfig,
    FeedForwardConfig,
)


class Onexlstm(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers):#, num_classes):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # Project input to hidden_size if dimensions differ
        self.input_proj = nn.Linear(input_size, hidden_size) if input_size != hidden_size else nn.Identity()

        # Configure mLSTM layer
        mlstm_layer_config = mLSTMLayerConfig(
            conv1d_kernel_size=4,      # Controls convolutional feature mixing
            qkv_proj_blocksize=4,      # Projection block size for QKV transformations
            num_heads=4                # Number of parallel memory heads
        )

        # mLSTM block configuration
        mlstm_block_config = mLSTMBlockConfig(mlstm=mlstm_layer_config)


        slstm_block_config = sLSTMBlockConfig(
            slstm=sLSTMLayerConfig(
                backend="cuda",
                num_heads=4,
                conv1d_kernel_size=4,
                bias_init="powerlaw_blockdependent"
            ),
            feedforward=FeedForwardConfig(proj_factor=1.3, act_fn="gelu")
        )

        # xLSTM stack configuration
        xlstm_config = xLSTMBlockStackConfig(
            mlstm_block=mlstm_block_config,
            slstm_block=slstm_block_config,
            context_length=256,        # Maximum sequence length expected
            num_blocks=num_layers,     # Number of mLSTM layers
            embedding_dim=hidden_size, # Same as LSTM's hidden_size
            slstm_at=[]                # Empty list = use only mLSTM blocks
        )

        # Create xLSTM stack with mLSTM blocks
        self.xlstm_stack = xLSTMBlockStack(xlstm_config)

        # Regularization and output layer
        self.dropout = nn.Dropout(0.3)
        #self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        # Ensure correct input dimensions
        if x.dim() == 2:
            x = x.unsqueeze(0)

        # Project input features to hidden dimension
        x = self.input_proj(x)

        # Forward pass through mLSTM blocks
        out = self.xlstm_stack(x)  # Shape: [batch, seq_len, hidden_size]

        # Get final timestep and apply dropout
        out = self.dropout(out[:, -1, :])

        # Final classification layer
        #return self.fc(out)
        return out

class Stackxlstm(nn.Module):
    def __init__(self, modellist):
        super().__init__()
        self.audio_model_speaker = modellist[0]
        self.audio_model_con = modellist[1]
        #self.text_model_speaker = modellist[1]
        #self.audio_model_con = modellist[2]
        #self.text_model_con = modellist[3]

    def forward(self, a1, a2):#t1, a2, t2):
        a1 = self.audio_model_speaker(a1)
        #t1 = self.text_model_speaker(t1)
        a2 = self.audio_model_con(a2)
        #t2 = self.text_model_con(t2)

        return a1, a2#t1, a2, t2


class ForgetGateStackedxlstm(nn.Module):
    def __init__(self, num_features, model, hidden_size, num_classes):
        super().__init__()
        largest = torch.rand(4) * 1 + 2   # Larger values around 3
        middle = torch.rand(4) * 1        # Around 0 (moderate)
        smallest = torch.rand(4) * 1 - 2 # Smaller values around -3

        # Concatenate them into a single tensor
        # init_values = torch.cat([largest, middle, smallest])

        # Register as a learnable parameter
        self.forget_gate = nn.Linear(1536, 5) # 786 is the x
        #self.forget_gate = nn.Parameter(torch.randn(num_features))  # Learnable forget weights
        self.sigmoid = nn.Sigmoid()
        self.stackmodel = model
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        """
        x: List of 12 feature matrices, each of shape (batch_size, seq_len, dim, 12) or similar.
        Returns: List of gated feature matrices.
        """
        tensors = []
        j = 0
        current_state = x[..., 0].squeeze(-1)
        for i in range(0, 6, 2):
            a1 = x[..., i].squeeze(-1)
            a2 = x[..., i + 1].squeeze(-1)
            #t1 = x[..., i + 2].squeeze(-1)
            #t2 = x[..., i + 3].squeeze(-1)
            result = self.stackmodel[j](a1, a2) #t1, a2, t2)
            tensors.append(result[0])
            tensors.append(result[1])
            #tensors.append(result[2])
            #tensors.append(result[3])

            j += 1
        tensors = torch.stack(tensors, dim=0)
        batch = tensors.shape[1]
        gate_values = torch.mean(self.sigmoid(self.forget_gate(current_state.reshape(batch, -1))), axis=0)  # (11,) shape, one value per feature
        gated_features = [tensors[0]]
        gated_features.extend([tensors[i + 1] * gate_values[i] for i in range(len(tensors) - 1)])  # Feature-wise gating
        out = torch.stack(gated_features, dim=0).permute(1, 0, 2).reshape(batch, -1)
        #out1 = tensors.permute(1, 0, 2).reshape(batch, -1)
        return self.fc(out)

def main():
    from torch.optim.lr_scheduler import ReduceLROnPlateau
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # Lets Load audio features
    audio_data = np.load("../with_oppo_IEMOCAP_audio_features_768.npy", allow_pickle=True).item()
    audio_features = audio_data['features']

    # Lets Load text features
    text_data = np.load("../with_oppo_IEMOCAP_text_features_768.npy", allow_pickle=True).item()
    text_features = text_data['features']
    text_labels = text_data['labels']

    metadata = pd.read_csv('../IEMOCAP_extracted_emotions.csv')

    file_to_prev = dict(zip(metadata['fileid'], metadata['prev']))

    # We just propose t-2 ~ t
    a1_0, a2_0, t1_0, t2_0 = [], [], [], []
    a1_1, a2_1, t1_1, t2_1 = [], [], [], []
    a1_2, a2_2, t1_2, t2_2 = [], [], [], []
    y = []
    # Define the selected classes: angry (0), happy (5), neutral (6), sad (8)
    selected_classes = [0, 5, 6, 8]
    label_mapping = {0: 0, 5: 1, 6: 2, 8: 3}
    zeros_array = np.zeros(768)

    def fill_features(a1, a2, t1, t2, pos):
        a1.append(audio_data['features'][pos])
        a2.append(audio_data['oppo_prev'][pos])
        t1.append(text_data['features'][pos])
        t2.append(text_data['oppo_prev'][pos])
        return a1, a2, t1, t2

    def fill_zero(a1, a2, t1, t2):
        a1.append(zeros_array)
        a2.append(zeros_array)
        t1.append(zeros_array)
        t2.append(zeros_array)
        return a1, a2, t1, t2

    # organise and clean the data
    for pos in range(len(audio_data['fileid'])):
        if audio_data['labels'][pos] not in selected_classes:
            continue
        a1_0, a2_0, t1_0, t2_0 = fill_features(a1_0, a2_0, t1_0, t2_0, pos)
        y.append(text_data['labels'][pos])

        prev = file_to_prev[audio_data['fileid'][pos]]

        try:
            pos1 = np.where(audio_data['fileid'] == prev)[0][0]
            a1_1, a2_1, t1_1, t2_1 = fill_features(a1_1, a2_1, t1_1, t2_1, pos1)

        except:
            a1_1, a2_1, t1_1, t2_1 = fill_zero(a1_1, a2_1, t1_1, t2_1)
            a1_2, a2_2, t1_2, t2_2 = fill_zero(a1_2, a2_2, t1_2, t2_2)
            continue

        try:
            prev = file_to_prev[audio_data['fileid'][pos1]]
            pos2 = np.where(audio_data['fileid'] == prev)[0][0]
            a1_2, a2_2, t1_2, t2_2 = fill_features(a1_2, a2_2, t1_2, t2_2, pos2)
        except:
            a1_2, a2_2, t1_2, t2_2 = fill_zero(a1_2, a2_2, t1_2, t2_2)

    a1_0, a2_0, t1_0, t2_0 = np.vstack(a1_0), np.vstack(a2_0), np.vstack(t1_0), np.vstack(t2_0),
    a1_1, a2_1, t1_1, t2_1 = np.vstack(a1_1), np.vstack(a2_1), np.vstack(t1_1), np.vstack(t2_1),
    a1_2, a2_2, t1_2, t2_2 = np.vstack(a1_2), np.vstack(a2_2), np.vstack(t1_2), np.vstack(t2_2),

    y = np.array([label_mapping[label] for label in y])

    # features = np.stack([a1_0, a2_0, t1_0, t2_0, a1_1, a2_1, t1_1, t2_1, a1_2, a2_2, t1_2, t2_2], axis=2)

    features = np.stack([
        np.concatenate([a1_0, t1_0], axis=-1),
        np.concatenate([a2_0, t2_0], axis=-1),
        np.concatenate([a1_1, t1_1], axis=-1),
        np.concatenate([a2_1, t2_1], axis=-1),
        np.concatenate([a1_2, t1_2], axis=-1),
        np.concatenate([a2_2, t2_2], axis=-1)
    ], axis=2)

    time_steps = 16
    features_per_step = features.shape[1] // time_steps
    features = features.reshape(features.shape[0], time_steps, features_per_step, 6)

    # concat all 4 into one feature
    # features = np.stack([a1_0, a2_0, t1_0, t2_0, a1_1, a2_1, t1_1, t2_1, a1_2, a2_2, t1_2, t2_2], axis=1)

    # time_steps = 16
    # features_per_step = features.shape[2] // time_steps
    # features = features.reshape(features.shape[0], 6, time_steps, features_per_step)
    # features = np.transpose(features, (0, 2, 1, 3))
    # features = features.reshape(features.shape[0], time_steps, 12 * features_per_step)

    # Split into train (80%), validation (10%), test (10%)
    train_data, temp_data, train_labels, temp_labels = train_test_split(features, y,
                                                                        test_size=0.2)  # shape [number of sample, hidden dim, 12], 12 as we have t-2 ~ t and each has 4
    valid_data, test_data, valid_labels, test_labels = train_test_split(temp_data, temp_labels, test_size=0.5)

    X_train = torch.tensor(train_data, dtype=torch.float32)
    y_train = torch.tensor(train_labels, dtype=torch.long)
    X_val = torch.tensor(valid_data, dtype=torch.float32)
    y_val = torch.tensor(valid_labels, dtype=torch.long)
    X_test = torch.tensor(test_data, dtype=torch.float32)
    y_test = torch.tensor(test_labels, dtype=torch.long)
    # Create DataLoaders
    train_dataset = TensorDataset(X_train, y_train)
    val_dataset = TensorDataset(X_val, y_val)
    test_dataset = TensorDataset(X_test, y_test)

    batch_size = 32

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    print("train_dataset.shape",len(train_dataset))
    print("val_dataset.shape", len(val_dataset))
    print("test_dataset.shape", len(test_dataset))

    # Model parameters
    input_size = features_per_step  # 32 based on your 512/16 split
    hidden_size = 512
    num_layers = 8

    model_list = []

    for i in range(6):
        model = Onexlstm(input_size, hidden_size, num_layers).to(device)
        model_list.append(model)

    stack_model1 = Stackxlstm(model_list[0:2]).to(device)
    stack_model2 = Stackxlstm(model_list[2:4]).to(device)
    stack_model3 = Stackxlstm(model_list[4:6]).to(device)

    final_model = ForgetGateStackedxlstm(6, [stack_model1, stack_model2, stack_model3], hidden_size * 6, 4).to(device)

    # Try concat at first place
    # # final_model = Onexlstm(input_size * 12, hidden_size, num_layers, 4).to(device)
    #
    # optimizer = optim.Adam(final_model.parameters(), lr=0.001, weight_decay=1e-4)
    # # scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=3, verbose=True)
    # criterion = nn.CrossEntropyLoss()
    #
    # best_val_f1 = 0.0
    # early_stop = 20
    # early = 0
    # for epoch in range(100):
    #     # Training phase
    #     final_model.train()
    #     train_loss = 0.0
    #     for inputs, labels in train_loader:
    #         inputs, labels = inputs.to(device), labels.to(device)
    #         optimizer.zero_grad()
    #
    #         outputs = final_model(inputs)
    #         loss = criterion(outputs, labels)
    #         loss.backward()
    #         optimizer.step()
    #         train_loss += loss.item() * inputs.size(0)
    #
    #     # Validation phase
    #     final_model.eval()
    #     val_loss = 0.0
    #     val_preds = []
    #     val_true = []
    #     with torch.no_grad():
    #         for inputs, labels in val_loader:
    #             inputs, labels = inputs.to(device), labels.to(device)
    #             outputs = final_model(inputs)
    #             loss = criterion(outputs, labels)
    #             val_loss += loss.item() * inputs.size(0)
    #             _, preds = torch.max(outputs, 1)
    #             val_preds.extend(preds.cpu().numpy())
    #             val_true.extend(labels.cpu().numpy())
    #
    #     # Calculate average losses and accuracy
    #     train_loss /= len(train_loader.dataset)
    #     val_loss /= len(val_loader.dataset)
    #     val_acc = accuracy_score(val_true, val_preds)
    #
    #     # Calculate F1 score (using 'macro' average; change as needed)
    #     val_f1 = f1_score(val_true, val_preds, average='macro')
    #
    #     # Scheduler step (using validation loss in this example)
    #     # scheduler.step(val_loss)
    #
    #     print(f"Epoch {epoch + 1:03d}: "
    #           f"Train Loss: {train_loss:.4f} | "
    #           f"Val Loss: {val_loss:.4f} | "
    #           f"Val Acc: {val_acc:.4f} | "
    #           f"Val F1: {val_f1:.4f}")
    #
    #     # Save the best model based on validation F1 score
    #     if val_f1 > best_val_f1:
    #         best_val_f1 = val_f1
    #         torch.save(final_model.state_dict(), './best_model_1.pth')
    #         print(f"--> New best model saved with Val f1: {best_val_f1:.4f}")
    #         early = 0
    #     else:
    #         early += 1
    #     if early >= early_stop:
    #         break
    #
    # warnings.filterwarnings("ignore", category=FutureWarning)
    # # Lets map the labels
    target_mapping = {0: "angry", 1: "happy", 2: "neutral", 3: "sad"}
    #
    target_names = [target_mapping[i] for i in sorted(target_mapping.keys())]

    # --------------------------------------------------
    # Final Evaluation

    final_model.load_state_dict(torch.load('../best_model_11.pth',
                                           map_location=torch.device('cpu'),
                                           weights_only=True))
    final_model.eval()

    test_preds = []
    test_true = []
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = final_model(inputs)
            _, preds = torch.max(outputs, 1)
            test_preds.extend(preds.cpu().numpy())
            test_true.extend(labels.cpu().numpy())

    accuracy = accuracy_score(test_true, test_preds)
    print("\nFinal Test Results on iemocap data:")
    print(f"Accuracy: {accuracy:.4f}")

    report = classification_report(test_true, test_preds, target_names=target_names, digits=4, zero_division=0)
    print("\nClassification Report:")
    print(report)
    #
    # print("Forget Gate Weights:\n", final_model.forget_gate.data)  # or .detach()
    #
    # ============================ 生成 DED 所需数据 ============================

    # # ✅ 加载 `final_model` 并运行 DED 评估
    # final_model.load_state_dict(torch.load('../best_model_11.pth',
    #                                        map_location=torch.device('cpu'),
    #                                        weights_only=True))
    # final_model.eval()
    #
    # out_dict = {}
    # emo_dict = {}
    #
    # # 只用 `val_loader`
    # with torch.no_grad():
    #     for idx in range(len(y_val)):
    #         fileid = metadata["fileid"][idx]
    #         inputs = X_val[idx].unsqueeze(0).to(device)
    #
    #         logits = final_model(inputs).squeeze().cpu().numpy()
    #         out_dict[fileid] = logits
    #
    #         emo_dict[fileid] = y_val[idx].item()
    #
    #
    # # 生成 dialogs
    # dialogs = defaultdict(list)
    # for fileid in metadata["fileid"][:len(y_val)]:
    #     dialog_id = re.sub(r'_F\d+$|_M\d+$', '', fileid)
    #     dialogs[dialog_id].append(fileid)
    # print('len_val', len(y_val))
    # # -------------
    # # 用全部的数据集
    # # with torch.no_grad():
    # #     for dataset, y_dataset in [(X_train, y_train), (X_val, y_val), (X_test, y_test)]:
    # #         for idx in range(len(y_dataset)):
    # #             fileid = metadata["fileid"][idx]
    # #             inputs = dataset[idx].unsqueeze(0).to(device)
    # #
    # #             logits = final_model(inputs).squeeze().cpu().numpy()
    # #             out_dict[fileid] = logits
    # #
    # #             emo_dict[fileid] = y_dataset[idx].item()
    # #
    # # dialogs = defaultdict(list)
    # # for fileid in out_dict.keys():
    # #     dialog_id = re.sub(r'_F\d+$|_M\d+$', '', fileid)
    # #     dialogs[dialog_id].append(fileid)
    # #
    # spk_dialogs = utils.split_dialog(dialogs)
    #
    # # print(emo_dict)
    # # print('-------')
    # # print(out_dict)
    # # print('--------')
    # # print(dialogs)
    #
    # pred_classes = [np.argmax(v) for v in out_dict.values()]
    # unique_pred = np.unique(pred_classes)
    # print(f"预测类别分布: {np.bincount(pred_classes)}")
    # print(f"唯一预测类别: {unique_pred}")
    #
    # nan_count = sum(np.isnan(v).any() for v in out_dict.values())
    # print(f"包含NaN的预测数: {nan_count}")
    #
    # sample_fid = next(iter(out_dict))
    # print(f"示例预测 '{sample_fid}':")
    # print(f"  logits: {out_dict[sample_fid]}")
    # print(f"  预测类别: {np.argmax(out_dict[sample_fid])}")
    # print(f"  真实标签: {emo_dict[sample_fid]}")
    #
    # logging.basicConfig(stream=sys.stdout,
    #                     format='%(asctime)s %(levelname)s:%(message)s',
    #                     level=logging.INFO,
    #                     datefmt='%I:%M:%S')
    #
    # args = parse_args()
    #
    # print("\n=== 对话结构验证 ===")
    # empty_dialogs = [k for k, v in dialogs.items() if not v]
    # print(f"空对话数量: {len(empty_dialogs)}")
    #
    # # 检查每个对话中的utterance是否都在emo_dict中
    # invalid_utterances = []
    # for dialog_id, utterances in dialogs.items():
    #     for utt in utterances:
    #         if utt not in emo_dict:
    #             invalid_utterances.append(utt)
    #
    # print(f"对话中无效utterance数量: {len(invalid_utterances)}")
    # if invalid_utterances:
    #     print("示例无效utterance:", invalid_utterances[:3])
    # print('=' * 60 + '\n')
    # logging.info('Parameters are:\n%s\n', json.dumps(vars(args), sort_keys=False, indent=4))
    # print('=' * 60 + '\n')
    #
    # if args.transition_bias > 0:
    #     # Use given p_0
    #     p_0 = args.transition_bias
    #
    # else:
    #     # Estimate p_0 of ALL dialogs.
    #     p_0, total_transit = utils.transition_bias(spk_dialogs, emo_dict)
    #
    #     print("\n" + "#" * 50)
    #     logging.info('p_0: %.3f , total transition: %d\n' % (p_0, total_transit))
    #     print("#" * 50)
    #
    #     bias_dict = utils.get_val_bias(spk_dialogs, emo_dict)
    #     print("#" * 50 + "\n")
    #
    # trace = []
    # label = []
    # org_pred = []
    # DED = bs.BeamSearch(p_0, args.crp_alpha, args.num_state,
    #                     args.beam_size, args.test_iteration, emo_dict, out_dict)
    #
    # for i, dia in enumerate(dialogs):
    #     logging.info("Decoding dialog: {}/{}, {}".format(i, len(dialogs), dia))
    #
    #     # Apply p_0 estimated from other 4 sessions.
    #     DED.transition_bias = bias_dict[dia[:5]]
    #
    #     # Beam search decoder
    #     out = DED.decode(dialogs[dia])
    #
    #     trace += out
    #     label += [utils.convert_to_index(emo_dict[utt]) for utt in dialogs[dia]]
    #     org_pred += [np.argmax(out_dict[utt]) for utt in dialogs[dia]]
    #     if args.verbosity > 0:
    #         logging.info("Output: {}\n".format(out))
    #
    # print("#" * 50 + "\n")
    # # Print the results of emotino classifier module
    # uar, acc, conf = utils.evaluate(org_pred, label)
    # logging.info('Original performance: uar: %.3f, acc: %.3f' % (uar, acc))
    #
    # # Eval ded outputs
    # results = vars(args)
    # uar, acc, conf = utils.evaluate(trace, label)
    # logging.info('DED performance: uar: %.3f, acc: %.3f' % (uar, acc))
    # logging.info('Confusion matrix:\n%s' % conf)
    #
    # # Save results
    # results['uar'] = uar
    # results['acc'] = acc
    # results['conf'] = str(conf)
    # logging.info('Save results:')
    # logging.info('\n%s\n', json.dumps(results, sort_keys=False, indent=4))
    # json.dump(results, open(args.out_dir + '/%s.json' % args.result_file, "w"))

if __name__ == '__main__':
    main()
